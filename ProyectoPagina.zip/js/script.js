//document.getElementById("principal").innerHTML = '<div class="topLogo"><center><img src="img/logo.png"></center></div><div class="nav"><a class="active" href="#news">Proyecto</a><img src="img/menu.png" width="10%" height="10%"></div><div class="navInfo"><center><ul ><a class="active" href="#home">Principal</a><a href="#news">Proyecto</a><a href="#contact">Clientes</a><a href="#about">Recursos</a><a href="#about">Relaciones</a></ul><footer><marquee>POWERED BY RAULSHP</marquee></footer></center></div>';


function myFunctionAbrir() {
	var modal = document.getElementById("navInfo");
	var modal1 = document.getElementById("varnav");
	modal.style.display = "block";
	modal1.style.display = "none";
	document.getElementById("idclose").innerHTML = '<img src="img/menu2.png" width="10%" id="varnav1" onclick="myFunction1()" height="10%">';
}

function myFunction1() {
	var modal = document.getElementById("navInfo");

	modal.style.display = "none";

	var modal1 = document.getElementById("varnav1");
	modal1.style.display = "none";
	var modal2 = document.getElementById("varnav");
	modal2.style.display = "block";
}

		
		
		


